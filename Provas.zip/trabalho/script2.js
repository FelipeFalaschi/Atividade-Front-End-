function add() {

    // Criar o novo card
    var novoCard = document.createElement("div");
    novoCard.className = "card";
    novoCard.style.width = "22rem";

    // Imagem
    var img = document.createElement("img");
    img.src = "img/Lucas_Paqueta.webp";
    img.className = "card-img-top";
    img.alt = "Lucas Paquetá";

    var cardBody = document.createElement("div");
    cardBody.className = "card-body";

    var titulo = document.createElement("h5");
    titulo.className = "card-title";

    var spanNome = document.createElement("span");
    spanNome.className = "card-title";
    spanNome.textContent = "Lucas Tolentino Coelho de Lima";

    var spanRank = document.createElement("span");
    spanRank.className = "badge text-bg-secondary";
    spanRank.textContent = "8,8";

    titulo.appendChild(spanNome);
    titulo.appendChild(spanRank);

    var paragrafo = document.createElement("p");
    paragrafo.className = "card-text";

    var spanData = document.createElement("span");
    spanData.innerHTML = "<strong>Nascimento:</strong> 27/08/1997";

    var br1 = document.createElement("br");

    var spanAltura = document.createElement("span");
    spanAltura.innerHTML = "<strong>Altura:</strong> 1,80";

    var br2 = document.createElement("br");

    var spanPosicao = document.createElement("span");
    spanPosicao.innerHTML = "<strong>Posição:</strong> Meio-campista";

    var br3 = document.createElement("br");

    paragrafo.appendChild(spanData);
    paragrafo.appendChild(br1);
    paragrafo.appendChild(spanAltura);
    paragrafo.appendChild(br2);
    paragrafo.appendChild(spanPosicao);
    paragrafo.appendChild(br3);

    cardBody.appendChild(titulo);
    cardBody.appendChild(paragrafo);

    novoCard.appendChild(img);
    novoCard.appendChild(cardBody);

    document.getElementById("Cards").appendChild(novoCard);
}