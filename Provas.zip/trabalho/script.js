function revelar() {
    document.querySelector(".card-img-top").src = "_vinicius_junior.png";

    document.getElementById("Nome").childNodes[0].textContent = "Vinícius José Paixão de Oliveira Júnior";
    document.getElementById("Rank").textContent = "9.5";
    document.getElementById("Data_Nas").textContent = "📅 Data de Nascimento: 12/07/2000 (25 anos)";
    document.getElementById("Altura").textContent = "📏 Altura: 1,76 m";
    document.getElementById("Posição ").textContent = "🏃 Posição: Ponta-esquerda / Atacante";

    document.getElementById("Nome").classList.remove("placeholder-glow");
    document.querySelector(".card-text").classList.remove("placeholder-glow");

    document.getElementById("Data_Nas").classList.remove("placeholder");
    document.getElementById("Data_Nas").classList.add("card-text");

    document.getElementById("Altura").classList.remove("placeholder");
    document.getElementById("Altura").classList.add("card-text");

    document.getElementById("Posição ").classList.remove("placeholder");
    document.getElementById("Posição ").classList.add("card-text");
}